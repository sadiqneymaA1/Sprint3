# Overview

This is a basic Hello World Program. I created this to demonstrate the use of visual studio code, Github, and Python Integrated together.

{Provide a description of your software}

{Describe your purpose for creating this software.}

{Provide a link to your YouTube demonstration.  It should be a one minute demo of the software running and a walkthrough of the code.}

[Software Demo Video](http://youtube.link.goes.here)

# Development Environment

* Visual Studio Code
* Pyhton 3.9 32-bit
* Git/ Github

{Describe the tools that you used to develop the software}

I installed the following
* Git
* Python 3
* Visual Studio code 
I also created a Git hub account. 

{Describe the programming language that you used}

I used Python Programming Language

# Useful Websites

{Make a list of websites that you found helpful in this project}
* [Visual Studio Code & Github](https://code.visualstudio.com/Download)
* [Web Site Name](https://www.python.org/downloads/)