begin
  dbms_output.put_line('Hello World!');
end;
/
