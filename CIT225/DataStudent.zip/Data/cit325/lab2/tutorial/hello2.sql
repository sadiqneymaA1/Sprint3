begin
  dbms_output.put_line('Hello '||&1||'!');
end;
/
