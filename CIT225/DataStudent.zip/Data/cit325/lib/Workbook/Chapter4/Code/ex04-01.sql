-- ex04-01.sql
-- Chapter 4, Oracle Database 11g PL/SQL Programming Workbook
-- by Michael McLaughlin and John Harper
--
-- Subject: Missing semi-colon
---------------------------------------------------------------------------
BEGIN
  DBMS_OUTPUT.PUT_LINE ( 'Hello World!' )
END;
/
