@Introduction/Code/create_workbook_store.sql
SELECT object_name, object_type FROM user_objects;
-- @../lib/cleanup.sql
-- SELECT object_name, object_type FROM user_objects;
