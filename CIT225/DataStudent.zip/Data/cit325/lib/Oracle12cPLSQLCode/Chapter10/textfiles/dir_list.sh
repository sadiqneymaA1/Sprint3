/usr/bin/ls /u01/app/oracle/upload/textfile | /usr/bin/cat
