/*
||  Name:          apply_plsql_lab8.sql
||  Date:          11 Nov 2016
||  Purpose:       Complete 325 Chapter 9 lab.
*/

-- Open log file.
SPOOL apply_plsql_lab8.txt

-- Enter your solution here.

-- Close log file.
SPOOL OFF
